package com.example.todobackendapp.controller;

import com.example.todobackendapp.entity.Todo;
import com.example.todobackendapp.service.TodoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/todos")
@CrossOrigin(origins = "http://localhost:5173")
public class TodoController {

    private final TodoService service;

    public TodoController(TodoService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Todo> createTodo(@Valid @RequestBody Todo todo) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(service.createTodo(todo));
    }

    @GetMapping
    public ResponseEntity<List<Todo>> getTodos(
            @RequestParam(required = false) Boolean completed) {
        return ResponseEntity.ok(service.getAllTodos(completed));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Todo> updateTodo(
            @PathVariable Long id,
            @RequestBody Todo todo) {
        return ResponseEntity.ok(service.updateTodo(id, todo));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTodo(@PathVariable Long id) {
        service.deleteTodo(id);
        return ResponseEntity.noContent().build();
    }
}