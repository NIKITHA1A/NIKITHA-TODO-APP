package com.example.todobackendapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoBackendAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(TodoBackendAppApplication.class, args);
    }

}
