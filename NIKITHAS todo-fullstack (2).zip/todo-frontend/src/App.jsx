import { useEffect, useState } from "react";
import axios from "axios";

const API = "http://localhost:8080/api/todos";

function App() {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState("");

  // Fetch all todos from backend
  const fetchTodos = async () => {
    const response = await axios.get(API);
    setTodos(response.data);
  };

  // Load todos when page loads
  useEffect(() => {
    fetchTodos();
  }, []);

  // Add new todo
  const addTodo = async () => {
  console.log("Add button clicked");

  if (!title.trim()) {
    console.log("Title is empty");
    return;
  }

  try {
    const response = await axios.post(API, {
      title: title,
      description: "",
      completed: false
    });

    console.log("POST success:", response.data);
    setTitle("");
    fetchTodos();
  } catch (error) {
    console.error("POST error:", error);
  }
};

  // Toggle completed
  const toggleTodo = async (todo) => {
    await axios.put(`${API}/${todo.id}`, {
      ...todo,
      completed: !todo.completed
    });

    fetchTodos();
  };

  // Delete todo
  const deleteTodo = async (id) => {
    await axios.delete(`${API}/${id}`);
    fetchTodos();
  };

  return (
    <div style={{ padding: "30px" }}>
      <h2>Todo Application</h2>

      <div>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Enter todo"
        />
        <button onClick={addTodo}>Add</button>
      </div>

      <ul>
        {todos.map((todo) => (
          <li key={todo.id}>
            <span
              style={{
                textDecoration: todo.completed ? "line-through" : "none",
                marginRight: "10px"
              }}
            >
              {todo.title}
            </span>

            <button onClick={() => toggleTodo(todo)}>
              {todo.completed ? "Undo" : "Complete"}
            </button>

            <button onClick={() => deleteTodo(todo.id)}>
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;